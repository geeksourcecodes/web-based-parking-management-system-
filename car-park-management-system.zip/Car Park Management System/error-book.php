<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Car Park Management System</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	<?php
			include('inc/head.php');
	?>
</head>
<body>
	<section id="container">
	<?php
			include('inc/header.php');
						
	?>
	
	<section id="content">
	<img src="src/bg.png" style="position:absolute; z-index:-1; margin:0;"/>
		<p style="text-align:center; color:white; background:red; border:solid 1px black;padding:5px;">
			<b>Booking Error!</b> </br>Please ensure you have entered correct information and the PL you are selecting is not booked.</p>
	</section>
	<?php
			include('inc/footer.php');
	?>
	</section>
	
</body>
</html>