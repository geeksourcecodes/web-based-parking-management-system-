<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Car Park Management System</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	<?php
			include('inc/head.php');
	?>
</head>
<body>
	<section id="container">
	<?php
			include('inc/header.php');
						
	?>
	
	<section id="content">
	<div>
		<vhead>Welcome To Car Park Management System </br></vhead>
	</div>
	<div style="text-align:center; font-weight:bold; margin-top:310px;font-size:28px;">
		<p>We offer cashless car parking services in town.</br>Book Now or Unbook</p>
	</div>
	</section>
	<?php
			include('inc/footer.php');
	?>
	</section>
	
</body>
</html>