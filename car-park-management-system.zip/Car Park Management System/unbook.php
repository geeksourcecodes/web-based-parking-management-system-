<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Unbook</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	<?php
			include('inc/head.php');
	?>
</head>
<body>
	<section id="container">
	<?php
			include('inc/header.php');
						
	?>
	
	<section id="content">
	<p class="phead">Unbook Parking Lot</p>
	<a href="proc/unbook.php" class="unbook">Unbook Now</a>	
	
	</section>
	<?php
			include('inc/footer.php');
	?>
	</section>
	
</body>
</html>